//
//  ViewController.swift
//  FindPrime
//
//  Created by Shaan Gontia on 25/07/17.
//  Copyright © 2017 sgontia. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
	
	@IBOutlet var outputLabel: UILabel!
	
	@IBOutlet var inputtext: UITextField!
	@IBAction func findPrime(_ sender: Any) {
		var i = 0;
		var isPrime = true
		let number = Int(inputtext.text!)
		if number != nil {
			if i % number! == 0 {
				isPrime = false
			}
			i += 1
		}
		outputLabel.text = String(isPrime)
	}
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

