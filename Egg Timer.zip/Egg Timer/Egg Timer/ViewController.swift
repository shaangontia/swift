//
//  ViewController.swift
//  Egg Timer
//
//  Created by Shaan Gontia on 26/07/17.
//  Copyright © 2017 sgontia. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	var timer = Timer()
	@IBOutlet var timerLabel: UILabel!
	
	func processTimer() {
		let timerValue = Int(timerLabel.text!)
		timerLabel.text = String(timerValue! + 1)
	}
	
	@IBAction func decreaseTenSeconds(_ sender: Any) {
		let timerValue = Int(timerLabel.text!)
		if timerValue! > 0 {
			timerLabel.text = String(timerValue! - 10)
		}
	}
	
	@IBAction func addTenSeconds(_ sender: Any) {
		let timerValue = Int(timerLabel.text!)
		timerLabel.text = String(timerValue! + 10)
	}
	
	@IBAction func resetTimer(_ sender: Any) {
		timerLabel.text = "200"
	}
	
	@IBAction func pauseTimer(_ sender: Any) {
		timer.invalidate()
	}
	
	@IBAction func startTimer(_ sender: Any) {
			timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.processTimer), userInfo: nil, repeats: true)
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
		timerLabel.text = "200"
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

