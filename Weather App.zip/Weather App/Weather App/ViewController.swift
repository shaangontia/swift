//
//  ViewController.swift
//  Weather App
//
//  Created by Shaan Gontia on 09/08/17.
//  Copyright © 2017 sgontia. All rights reserved.
//

import UIKit

enum constants: String {
	case cityError = "Please enter the city name."
	case urlError = "Could not find the weather for the city."
}

class ViewController: UIViewController  {

	
	@IBOutlet var cityText: UITextField!
	
	@IBOutlet weak var detailsLabel: UILabel!
	
	@IBAction func submitButton(_ sender: Any) {
		
		let cityName = NSString(string: cityText.text!)
		if cityName.length == 0 {
			detailsLabel.text = constants.cityError.rawValue
		} else {
		var message = ""
		let webURL = URL(string: "http://www.weather-forecast.com/locations/" + cityText.text!.replacingOccurrences(of: " ", with: "-") + "/forecasts/latest")!
		let request = NSMutableURLRequest(url: webURL)
		let task = URLSession.shared.dataTask(with: request as URLRequest) {
			data, response, error in
			
			if error != nil {
				print("Error")
			} else {
				if let responseData = data {
					let dataString = NSString(data: responseData, encoding: String.Encoding.utf8.rawValue)
					print(dataString!)
					var stringSeparator = "Weather Forecast Summary:</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">"
					if let content = dataString?.components(separatedBy: stringSeparator) {
						if content.count > 1 {
							stringSeparator = "</span>"
							let actualContent = content[1].components(separatedBy: stringSeparator)
							message = actualContent[0].replacingOccurrences(of: "&deg;", with: "°")
							print(message)
							
						}
					}
				}
			}
			if message == "" {
				message = constants.urlError.rawValue
			}
			DispatchQueue.main.sync(execute: {
				self.detailsLabel.text = message
			})
		}
		task.resume()
		}
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
		
	}
}

