//
//  ViewController.swift
//  Cat Yeara
//
//  Created by Shaan Gontia on 22/07/17.
//  Copyright © 2017 sgontia. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	@IBOutlet var catAgeText: UITextField!
	@IBOutlet var catAgeLabel: UILabel!
	
	@IBAction func calculateCatAgeButton(_ sender: Any) {
		if (catAgeText.text != "") {
			let age = Int(catAgeText.text!)! * 7
			catAgeLabel.text = String(age)
		} else {
			catAgeLabel.text = "Please enter the age !!!"
		}
	}
	override func viewDidLoad() {
		super.viewDidLoad()
			// Do any additional setup after loading the view, typically from a nib.
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

